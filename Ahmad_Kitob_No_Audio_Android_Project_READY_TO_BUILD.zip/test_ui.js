const vm = require('vm'), fs = require('fs'), path = require('path'), assert = require('assert');
const assets = path.join(__dirname, 'app/src/main/assets');
class Classes {
  constructor(){this.names=new Set(['hidden']);}
  toggle(k, f){if(f===undefined)f=!this.names.has(k);if(f)this.names.add(k);else this.names.delete(k);return f;}
  contains(k){return this.names.has(k)}
  add(k){this.names.add(k)}
  remove(k){this.names.delete(k)}
}
class Element {
  constructor(id){this.id=id;this.value='';this.textContent='';this.innerHTML='';this.src='';this.alt='';this.disabled=false;this.classList=new Classes();this.style={width:'',setProperty(){}};this.options=[];this.attrs={};}
  appendChild(c){this.options.push(c)}
  setAttribute(k,v){this.attrs[k]=v}
  getAttribute(k){return this.attrs[k]}
  focus(){}
  closest(){return null}
  addEventListener(){}
}
const elements={}, get=id=>elements[id]||(elements[id]=new Element(id));
const storage={db:{},getItem(k){return Object.prototype.hasOwnProperty.call(this.db,k)?this.db[k]:null},setItem(k,v){this.db[k]=v}};
const ctx={
  window:{KITOB_PAGES:[],scrollTo(){}},
  document:{getElementById:get,createElement:t=>new Element(t),documentElement:{style:{setProperty(k,v){this[k]=v}}},body:{classList:new Classes()},querySelectorAll:sel=>sel==='[data-tab]'?[get('tabUz'),get('tabAr')]:[],addEventListener(){}},
  localStorage:storage,console,setTimeout,clearTimeout,JSON,Array,Number,String,Math,Boolean,Set
};
ctx.window.document=ctx.document;get('tabUz').dataset={tab:'uz'};get('tabAr').dataset={tab:'ar'};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(assets,'book-data.js'),'utf8'),ctx,{timeout:10000});
vm.runInContext(fs.readFileSync(path.join(assets,'app.js'),'utf8'),ctx,{timeout:10000});
assert.equal(ctx.window.KITOB_PAGES.length,175);
assert.equal(get('pageSelect').options.length,175);
assert.match(get('uzText').innerHTML,/ЖАҲМИЙЛАР/);
assert.doesNotMatch(get('uzText').innerHTML,/Аҳмад ибн Ҳанбал • Ўзбекча таржима/);
get('latnBtn').onclick();assert.match(get('uzText').innerHTML,/JAHMIYLAR/);
get('cyrlBtn').onclick();assert.match(get('uzText').innerHTML,/ЖАҲМИЙЛАР/);
get('bigger').onclick();assert.equal(get('fontLabel').textContent,'26 px');
get('nightBtn').onclick();assert.equal(ctx.document.body.classList.contains('dark'),true);
get('dayBtn').onclick();assert.equal(ctx.document.body.classList.contains('dark'),false);
get('nextBtn').onclick();assert.equal(get('pageSelect').value,'2');
get('bookmarkBtn').onclick();assert.match(get('bookmarkBtn').textContent,/Белгиланган/);
get('tabAr').onclick();assert.equal(get('arSection').classList.contains('hidden'),false);
get('tabUz').onclick();assert.equal(get('uzSection').classList.contains('hidden'),false);
get('pageSelect').onchange({target:{value:'175'}});assert.equal(get('nextBtn').disabled,true);
assert.equal(get('arabicImage').src,'arabic/175.webp');
for(const name of ['speakUzBtn','speakArBtn','stopBtn','voiceStatus','arabicInput'])assert.equal(elements[name],undefined,'Audio control exists: '+name);
console.log('PASS: 175 Arabic pages, Cyrillic/Latin, font, themes, page navigation, bookmarks, tabs, no audio');
