(function(){
'use strict';
const P=window.KITOB_PAGES||[];
const $=id=>document.getElementById(id);
const TOTAL=P.length;
const mem={get(k){try{return localStorage.getItem('ahmad_reader_'+k)}catch(e){return null}},set(k,v){try{localStorage.setItem('ahmad_reader_'+k,String(v))}catch(e){}}};
const number=(v,d)=>v===null||v===undefined||v===''||!Number.isFinite(Number(v))?d:Number(v);
const clamp=(v,min,max)=>Math.max(min,Math.min(max,v));
const state={page:clamp(number(mem.get('page'),1),1,TOTAL),script:mem.get('script')==='latn'?'latn':'cyrl',theme:mem.get('theme')==='dark'?'dark':'light',font:clamp(number(mem.get('font'),24),18,68),tab:'uz',zoom:100};
const escapeHTML=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const cap={А:'A',а:'a',Б:'B',б:'b',В:'V',в:'v',Г:'G',г:'g',Д:'D',д:'d',Ё:'Yo',ё:'yo',Ж:'J',ж:'j',З:'Z',з:'z',И:'I',и:'i',Й:'Y',й:'y',К:'K',к:'k',Л:'L',л:'l',М:'M',м:'m',Н:'N',н:'n',О:'O',о:'o',П:'P',п:'p',Р:'R',р:'r',С:'S',с:'s',Т:'T',т:'t',У:'U',у:'u',Ф:'F',ф:'f',Х:'X',х:'x',Ц:'Ts',ц:'ts',Ч:'Ch',ч:'ch',Ш:'Sh',ш:'sh',Щ:'Shch',щ:'shch',Ъ:'ʼ',ъ:'ʼ',Ь:'',ь:'',Э:'E',э:'e',Ю:'Yu',ю:'yu',Я:'Ya',я:'ya',Ў:'Oʻ',ў:'oʻ',Ғ:'Gʻ',ғ:'gʻ',Қ:'Q',қ:'q',Ҳ:'H',ҳ:'h',Ы:'I',ы:'i'};
function latin(text){
 const a=Array.from(text), out=[];
 for(let i=0;i<a.length;i++){
  const ch=a[i];
  if(ch==='Е'||ch==='е'){
    const prev=a[i-1]||'';
    const first=!prev||/[\s(\[«“‘'\-—.,:;!?\n]/.test(prev)||/[АаОоИиУуЎўЭэЁёЮюЯяЕеЪъЬь]/.test(prev);
    out.push(first?(ch==='Е'?'Ye':'ye'):(ch==='Е'?'E':'e'));
  } else out.push(cap[ch]!==undefined?cap[ch]:ch);
 }
 return out.join('');
}
function cur(){return P[state.page-1]||{text:'',image:''}}
function currentText(){return state.script==='latn'?latin(cur().text):cur().text}
function bookmarks(){try{const b=JSON.parse(mem.get('bookmarks')||'[]');return Array.isArray(b)?b.filter(x=>Number.isInteger(x)&&x>=1&&x<=TOTAL):[]}catch(e){return []}}
function render(){
 const p=cur();
 $('pageSelect').value=String(state.page);
 $('prevBtn').disabled=state.page===1;
 $('nextBtn').disabled=state.page===TOTAL;
 const formatted=currentText();
 $('uzText').innerHTML='<div class="pagenote">'+(state.script==='latn'?'Asl nusxa':'Асл нусха')+' · '+state.page+' / '+TOTAL+'</div>'+(formatted?escapeHTML(formatted).split(/\n\s*\n/).map(x=>'<p>'+x.replace(/\n/g,' ')+'</p>').join(''):'<p class="empty">Ушбу бетнинг таржима матни қўшни бетда берилган. Арабча асл нусхани ёки қўшни бетни кўринг.</p>');
 $('arabicImage').src=p.image;
 $('arabicImage').alt='Арабча асл нусха · '+state.page+'-бет';
 $('bookmarkBtn').textContent=bookmarks().includes(state.page)?'★ Белгиланган':'☆ Белгилаш';
 mem.set('page',state.page);
}
function navigate(n){state.page=clamp(number(n,1),1,TOTAL);render();if(window.scrollTo)window.scrollTo(0,0)}
function setScript(s){state.script=s==='latn'?'latn':'cyrl';mem.set('script',state.script);for(const [id,sel] of [['cyrlBtn',state.script==='cyrl'],['latnBtn',state.script==='latn']]){$(id).classList.toggle('selected',sel);$(id).setAttribute('aria-pressed',String(sel))} $('uzText').setAttribute('lang','uz');render()}
function setFont(n){state.font=clamp(number(n,24),18,68);mem.set('font',state.font);document.documentElement.style.setProperty('--fontSize',state.font+'px');$('fontRange').value=state.font;$('fontLabel').textContent=state.font+' px'}
function setTheme(t){state.theme=t==='dark'?'dark':'light';mem.set('theme',state.theme);document.body.classList.toggle('dark',state.theme==='dark');for(const [id,sel] of [['dayBtn',state.theme==='light'],['nightBtn',state.theme==='dark']]){$(id).classList.toggle('selected',sel);$(id).setAttribute('aria-pressed',String(sel))}}
function setTab(t){state.tab=t==='ar'?'ar':'uz';for(const [section,show] of [['uzSection',state.tab==='uz'],['arSection',state.tab==='ar']])$(section).classList.toggle('hidden',!show);for(const [button,show] of [['tabUz',state.tab==='uz'],['tabAr',state.tab==='ar']]){$(button).classList.toggle('selected',show);$(button).setAttribute('aria-selected',String(show))}}
function toggleBookmark(){let b=bookmarks();if(b.includes(state.page))b=b.filter(n=>n!==state.page);else b.push(state.page);b.sort((a,b)=>a-b);mem.set('bookmarks',JSON.stringify(b));render()}
function togglePanel(name){for(const id of ['findPanel','bookmarkPanel','helpPanel']){const expand=id===name&&$(id).classList.contains('hidden');$(id).classList.toggle('hidden',!expand);const button={findPanel:'findToggle',bookmarkPanel:'bookmarkListBtn',helpPanel:'helpBtn'}[id];$(button).setAttribute('aria-expanded',String(expand))}if(name==='bookmarkPanel')showBookmarks();if(name==='findPanel'&&!$(name).classList.contains('hidden'))$('searchInput').focus()}
function showBookmarks(){let b=bookmarks();$('bookmarkPanel').innerHTML=b.length?b.map(n=>'<button class="result" type="button" data-goto="'+n+'">'+n+'-бет · Белгиланган</button>').join(''):'Ҳозирча белгилар йўқ'}
let searchTimer;
function search(){clearTimeout(searchTimer);searchTimer=setTimeout(()=>{
 const q=$('searchInput').value.trim().toLowerCase();
 if(q.length<2){$('searchResults').textContent='Камида икки ҳарф киритинг.';return}
 const results=[];
 for(const p of P){const s=state.script==='latn'?latin(p.text):p.text;const index=s.toLowerCase().indexOf(q);if(index>=0){const start=Math.max(0,index-55);results.push({n:p.n,excerpt:s.slice(start,Math.min(s.length,index+110)).replace(/\s+/g,' ')})}}
 $('searchResults').innerHTML=results.length?results.slice(0,75).map(x=>'<button class="result" type="button" data-goto="'+x.n+'"><strong>'+x.n+'-бет</strong><small>'+escapeHTML(x.excerpt)+'</small></button>').join(''):'Натижа йўқ.';
},120)}
for(const p of P){const opt=document.createElement('option');opt.value=p.n;opt.textContent=String(p.n);$('pageSelect').appendChild(opt)}
$('pageSelect').onchange=e=>navigate(+e.target.value);
$('prevBtn').onclick=()=>navigate(state.page-1);$('nextBtn').onclick=()=>navigate(state.page+1);
$('cyrlBtn').onclick=()=>setScript('cyrl');$('latnBtn').onclick=()=>setScript('latn');
$('dayBtn').onclick=()=>setTheme('light');$('nightBtn').onclick=()=>setTheme('dark');
$('fontRange').oninput=e=>setFont(+e.target.value);
$('smaller').onclick=()=>setFont(state.font-2);$('bigger').onclick=()=>setFont(state.font+2);
$('bookmarkBtn').onclick=toggleBookmark;$('bookmarkListBtn').onclick=()=>togglePanel('bookmarkPanel');$('findToggle').onclick=()=>togglePanel('findPanel');$('helpBtn').onclick=()=>togglePanel('helpPanel');
$('searchInput').oninput=search;
document.addEventListener('click',e=>{const b=e.target.closest('[data-goto]');if(b){navigate(+b.dataset.goto);$('findPanel').classList.add('hidden');$('bookmarkPanel').classList.add('hidden')}});
document.querySelectorAll('[data-tab]').forEach(el=>el.onclick=()=>setTab(el.dataset.tab));
$('scanZoom').oninput=e=>{state.zoom=+e.target.value;$('arabicImage').style.width=state.zoom+'%';$('zoomLabel').textContent=state.zoom+'%'};
setTheme(state.theme);setFont(state.font);setScript(state.script);setTab('uz');render();
})();
