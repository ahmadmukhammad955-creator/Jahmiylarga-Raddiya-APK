package uz.muhammadsharif.dorimiy;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.pdf.PdfRenderer;
import android.content.Context;
import android.content.res.Configuration;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;
import android.text.InputType;
import android.text.TextUtils;
import android.graphics.drawable.GradientDrawable;
import org.json.JSONArray;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Offline reader: all book content is packaged as an asset; no network permissions. */
public final class ReaderActivity extends Activity {
    private PdfRenderer renderer;
    private ParcelFileDescriptor descriptor;
    private PdfRenderer.Page openedPage;
    private Bitmap pageBitmap;
    private ZoomPageView pageView;
    private TextView progressText, titleText;
    private int pageIndex = 0;
    private boolean dark = false;
    private JSONArray searchIndex;
    private final int backgroundColor = Color.rgb(247,245,239);
    private final int headerColor = Color.rgb(22,35,47);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(headerColor);
        getWindow().setNavigationBarColor(headerColor);
        dark = getPreferences(0).getBoolean("night",false);
        try {
            File pdf = new File(getFilesDir(),"dorimiy_internal_v1.pdf");
            if (!pdf.isFile() || pdf.length() < 10000) {
                try (InputStream in=getAssets().open("dorimiy.pdf"); FileOutputStream out=new FileOutputStream(pdf)) {
                    byte[] buf=new byte[65536]; int n;
                    while((n=in.read(buf))!=-1) out.write(buf,0,n);
                }
            }
            descriptor = ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_ONLY);
            renderer = new PdfRenderer(descriptor);
            if (renderer.getPageCount() < 300) throw new IllegalStateException("Book incomplete");
        } catch(Exception ex){
            showFatal(ex.toString()); return;
        }
        pageIndex = Math.min(renderer.getPageCount()-1,
            Math.max(0,getPreferences(0).getInt("last_page",0)));
        makeUi();
        pageView.post(new Runnable(){@Override public void run(){showPage(pageIndex);}});
    }

    private void showFatal(String message) {
        new AlertDialog.Builder(this).setTitle("Китобни очиб бўлмади")
          .setMessage(message).setPositiveButton("Ёпиш",(a,b)->finish()).show();
    }

    private int dp(float size){return (int)(size*getResources().getDisplayMetrics().density+.5f);}

    private GradientDrawable pill(int color) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(8)); return d;
    }

    private Button button(String label, LinearLayout parent, View.OnClickListener onClick) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(13);
        b.setTextColor(Color.WHITE); b.setBackground(pill(0xFF314A59));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(46),1);
        p.setMargins(dp(3),dp(3),dp(3),dp(3)); parent.addView(b,p);
        b.setOnClickListener(onClick); return b;
    }

    private void makeUi(){
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(dark?0xFF101010:backgroundColor);
        setContentView(root);

        LinearLayout top = new LinearLayout(this);
        top.setPadding(dp(8),dp(8),dp(8),dp(8));
        top.setBackgroundColor(headerColor);
        top.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(top,new LinearLayout.LayoutParams(-1,dp(66)));

        titleText = new TextView(this);
        titleText.setText("Жаҳмийларга раддия\nИмом ад-Доримий · Муҳаммадшариф");
        titleText.setTextColor(Color.WHITE); titleText.setTextSize(14);
        titleText.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(titleText,new LinearLayout.LayoutParams(0,-1,1));
        Button search = button("Излаш",top,v->openSearch());
        Button tools  = button("⋮",top,v->openMenu());
        ((LinearLayout.LayoutParams)search.getLayoutParams()).width=dp(82);
        ((LinearLayout.LayoutParams)search.getLayoutParams()).weight=0;
        ((LinearLayout.LayoutParams)tools.getLayoutParams()).width=dp(50);
        ((LinearLayout.LayoutParams)tools.getLayoutParams()).weight=0;

        FrameLayout area = new FrameLayout(this);
        area.setBackgroundColor(dark?0xFF101010:backgroundColor);
        root.addView(area,new LinearLayout.LayoutParams(-1,0,1));
        pageView = new ZoomPageView(this);
        area.addView(pageView,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout bottom = new LinearLayout(this); bottom.setGravity(Gravity.CENTER_VERTICAL);
        bottom.setPadding(dp(7),dp(4),dp(7),dp(8)); bottom.setBackgroundColor(headerColor);
        root.addView(bottom,new LinearLayout.LayoutParams(-1,dp(68)));
        button("‹",bottom,v->showPage(pageIndex-1));
        progressText = new TextView(this); progressText.setGravity(Gravity.CENTER);
        progressText.setTextColor(Color.WHITE); progressText.setTextSize(14);
        progressText.setText("1 / " + renderer.getPageCount());
        bottom.addView(progressText,new LinearLayout.LayoutParams(0,dp(49),2));
        progressText.setOnClickListener(v->jumpToPage());
        button("›",bottom,v->showPage(pageIndex+1));
        button("☆",bottom,v->toggleBookmark());
    }

    private void showPage(int p){
        if (renderer==null || pageView==null || p<0 || p>=renderer.getPageCount())return;
        try {
            if(openedPage!=null){openedPage.close();openedPage=null;}
            if(pageBitmap!=null){pageBitmap.recycle();pageBitmap=null;}
            openedPage=renderer.openPage(p);
            int targetWidth=Math.max(800,Math.min(1850, getResources().getDisplayMetrics().widthPixels*2));
            int targetHeight=(int)((double)openedPage.getHeight() * targetWidth / openedPage.getWidth());
            pageBitmap=Bitmap.createBitmap(targetWidth,targetHeight, Bitmap.Config.ARGB_8888);
            Canvas canvas=new Canvas(pageBitmap);canvas.drawColor(Color.WHITE);
            Matrix transform=new Matrix(); transform.setScale((float)targetWidth/openedPage.getWidth(),(float)targetHeight/openedPage.getHeight());
            openedPage.render(pageBitmap,null,transform,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            pageIndex=p;
            pageView.display(pageBitmap,dark);
            progressText.setText((p+1)+" / "+renderer.getPageCount());
            getPreferences(0).edit().putInt("last_page",p).apply();
        } catch(Exception ex){Toast.makeText(this,"Саҳифа хатоси: "+ex.getMessage(),Toast.LENGTH_LONG).show();}
    }

    private void jumpToPage(){
        EditText input=new EditText(this);input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setText(String.valueOf(pageIndex+1));input.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this).setTitle("Саҳифа рақами (1–"+renderer.getPageCount()+")")
          .setView(input).setPositiveButton("Ўтиш",(d,w)->{
            try {showPage(Integer.parseInt(input.getText().toString())-1);}
            catch(Exception e){Toast.makeText(this,"Нотўғри рақам",Toast.LENGTH_SHORT).show();}
          }).setNegativeButton("Бекор",null).show();
    }

    private String bookmarkKey(){return "bookmark_"+pageIndex;}
    private boolean isBookmarked(int p){return getPreferences(0).getBoolean("bookmark_"+p,false);}
    private void toggleBookmark(){
        boolean value=!isBookmarked(pageIndex);
        getPreferences(0).edit().putBoolean(bookmarkKey(),value).apply();
        Toast.makeText(this,value?"Саҳифа сақланди":"Белги олиб ташланди",Toast.LENGTH_SHORT).show();
    }
    private void listBookmarks(){
        List<Integer> ids=new ArrayList<>();
        for(int i=0;i<renderer.getPageCount();i++)if(isBookmarked(i))ids.add(i);
        if(ids.isEmpty()){Toast.makeText(this,"Белгилар йўқ",Toast.LENGTH_SHORT).show();return;}
        String[] names=new String[ids.size()];
        for(int i=0;i<ids.size();i++)names[i]="Саҳифа "+(ids.get(i)+1);
        new AlertDialog.Builder(this).setTitle("Белгиланган саҳифалар")
         .setItems(names,(dlg,pos)->showPage(ids.get(pos))).setNegativeButton("Ёпиш",null).show();
    }

    private void openMenu(){
        String[] choices={"Саҳифага ўтиш","Белгилар","Бу саҳифани белгилаш",dark?"Кундузги кўриниш":"Тунги кўриниш","Муаллиф ва таржимон"};
        new AlertDialog.Builder(this).setTitle("Китоб имкониятлари").setItems(choices,(d,n)->{
          switch(n){
            case 0:jumpToPage();break;
            case 1:listBookmarks();break;
            case 2:toggleBookmark();break;
            case 3:dark=!dark;getPreferences(0).edit().putBoolean("night",dark).apply();makeUi();pageView.post(()->showPage(pageIndex));break;
            case 4:new AlertDialog.Builder(this).setTitle("Жаҳмийларга раддия")
              .setMessage("Муаллиф: Усмон ибн Саид ад-Доримий\nТаржима қилган: Муҳаммадшариф\n333 саҳифа · Ўзбекча (кирилл) ва арабча\nОфлайн ўқиш")
              .setPositiveButton("Тушунарли",null).show();break;
          }
        }).show();
    }

    private void loadIndex(){
        if(searchIndex!=null)return;
        try (InputStream in=getAssets().open("search_index.json")) {
            ByteArrayOutputStream out=new ByteArrayOutputStream();
            byte[] buf=new byte[8192];int n;
            while((n=in.read(buf))!=-1)out.write(buf,0,n);
            searchIndex=new JSONArray(out.toString("UTF-8"));
        }catch(Exception e){Toast.makeText(this,"Қидирув индекси очилмади",Toast.LENGTH_LONG).show();}
    }

    private void openSearch(){
        final EditText input=new EditText(this);input.setSingleLine(true);
        input.setHint("Китобдан сўз ёки ибора...");
        new AlertDialog.Builder(this).setTitle("Китобдан излаш")
         .setView(input).setPositiveButton("Излаш",(d,n)->doSearch(input.getText().toString()))
         .setNegativeButton("Бекор",null).show();
    }

    private void doSearch(String raw){
        String query=raw.trim().toLowerCase(new Locale("uz"));
        if(query.length()<2){Toast.makeText(this,"Камида 2 та ҳарф киритинг",Toast.LENGTH_SHORT).show();return;}
        loadIndex();if(searchIndex==null)return;
        List<Integer> found=new ArrayList<>();List<String> snippets=new ArrayList<>();
        for(int i=0;i<searchIndex.length();i++){
            String t=searchIndex.optString(i,"");
            int offset=t.toLowerCase(new Locale("uz")).indexOf(query);
            if(offset>=0){
                found.add(i);
                String excerpt=t.substring(Math.max(0,offset-42),Math.min(t.length(),offset+query.length()+70));
                snippets.add((i+1)+"-саҳифа: …"+excerpt+"…");
            }
        }
        if(found.isEmpty()){new AlertDialog.Builder(this).setTitle("Натижа")
             .setMessage("Топилмади").setPositiveButton("Ёпиш",null).show();return;}
        String[] items=snippets.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("Топилди: "+found.size()+" саҳифа")
         .setItems(items,(d,position)->showPage(found.get(position)))
         .setNegativeButton("Ёпиш",null).show();
    }

    @Override public void onBackPressed(){
        new AlertDialog.Builder(this).setTitle("Китобдан чиқиш")
        .setMessage("Ўқилган саҳифа сақланади.")
        .setPositiveButton("Чиқиш",(d,n)->finish())
        .setNegativeButton("Қолиш",null).show();
    }

    @Override public void onConfigurationChanged(Configuration newConfig){
        super.onConfigurationChanged(newConfig);
        if(pageView!=null) pageView.post(()->showPage(pageIndex));
    }

    @Override protected void onDestroy(){
        if(openedPage!=null){openedPage.close();openedPage=null;}
        if(pageBitmap!=null){pageBitmap.recycle();pageBitmap=null;}
        if(renderer!=null){renderer.close();renderer=null;}
        try {if(descriptor!=null)descriptor.close();}catch(Exception ignored){}
        super.onDestroy();
    }

    private class ZoomPageView extends ImageView {
        private final Matrix imageMatrix=new Matrix();
        private ScaleGestureDetector pinch;
        private GestureDetector taps;
        private float previousX,previousY;
        private float scale=1.0f;
        private boolean panning=false;
        private float downX,downY;

        ZoomPageView(Context c){
            super(c);setScaleType(ImageView.ScaleType.MATRIX);
            setBackgroundColor(dark?0xFF111111:backgroundColor);
            pinch=new ScaleGestureDetector(c,new ScaleGestureDetector.SimpleOnScaleGestureListener(){
                @Override public boolean onScale(ScaleGestureDetector d){
                    float newScale=Math.max(1.0f,Math.min(4f,scale*d.getScaleFactor()));
                    float factor=newScale/scale;scale=newScale;
                    imageMatrix.postScale(factor,factor,d.getFocusX(),d.getFocusY());
                    setImageMatrix(imageMatrix);invalidate();return true;
                }
            });
            taps=new GestureDetector(c,new GestureDetector.SimpleOnGestureListener(){
                @Override public boolean onDoubleTap(MotionEvent e){
                    if(scale>1.01f){resetFit();}
                    else {scale=2f;imageMatrix.postScale(2f,2f,e.getX(),e.getY());setImageMatrix(imageMatrix);}
                    return true;
                }
            });
        }
        void display(Bitmap bmp,boolean invert){
            setImageBitmap(bmp);
            if(invert){
                ColorMatrix cm = new ColorMatrix(new float[]{
                  -1,0,0,0,255, 0,-1,0,0,255, 0,0,-1,0,255, 0,0,0,1,0
                });
                setColorFilter(new ColorMatrixColorFilter(cm));
            }else clearColorFilter();
            setBackgroundColor(invert?Color.BLACK:backgroundColor);
            resetFit();
        }
        void resetFit(){
            if(getDrawable()==null || getWidth()<=0 || getHeight()<=0)return;
            float iw=getDrawable().getIntrinsicWidth(),ih=getDrawable().getIntrinsicHeight();
            if(iw<=0 || ih<=0)return;
            float fit=Math.min((float)getWidth()/iw,(float)getHeight()/ih);
            imageMatrix.reset();imageMatrix.postScale(fit,fit);
            imageMatrix.postTranslate((getWidth()-fit*iw)/2f,(getHeight()-fit*ih)/2f);
            scale=1f;setImageMatrix(imageMatrix);invalidate();
        }
        @Override public boolean onTouchEvent(MotionEvent ev){
            pinch.onTouchEvent(ev);taps.onTouchEvent(ev);
            switch(ev.getActionMasked()){
              case MotionEvent.ACTION_DOWN:
                downX=previousX=ev.getX();downY=previousY=ev.getY();panning=false;return true;
              case MotionEvent.ACTION_MOVE:
                if(ev.getPointerCount()==1 && scale>1.01f){
                    float dx=ev.getX()-previousX,dy=ev.getY()-previousY;
                    imageMatrix.postTranslate(dx,dy);setImageMatrix(imageMatrix);panning=true;
                }
                previousX=ev.getX(); previousY=ev.getY(); return true;
              case MotionEvent.ACTION_UP:
                float delta=ev.getX()-downX;
                if(scale<=1.01f && Math.abs(delta)>dp(75) && Math.abs(ev.getY()-downY)<dp(140)){
                    if(delta<0)showPage(pageIndex+1);else showPage(pageIndex-1);
                }
                return true;
            }
            return true;
        }
        @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){super.onSizeChanged(w,h,oldw,oldh);post(this::resetFit);}
    }
}
